$(document).ready(function(){
    $("#datepicker").datepicker({
        minDate: +1,
        dateFormat: "dd.mm.yy"
    });
});